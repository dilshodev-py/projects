BACKUP_DIR="/home/dilshod/backups/"
FILE_NAME=$BACKUP_DIR`date +%d-%m-%Y-%I-%M-%S`.tar
PGPASSWORD='1' sudo -S <<< "1234" -u postgres pg_dump -U postgres -F tar -f $FILE_NAME -d lesson_8