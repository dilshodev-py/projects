DB_PATH = "/home/dilshod/PycharmProjects/TgCLone/db/"


class DbService:
    def objects(self):
        pass


    def write(self, data: list):
        pass

