

current_user : Optional[User] = None
class UI:
    def main(self):
        menu = """
            1) Register
            2) Login
            3) Exit
            >>>"""
        match input(menu):
            case "1":
                self.register()
            case "2":
                self.login()
            case "3":
                return

    def register(self):
        user = {
            "id" : "User().sequence_id()",
            "phone_number": input("phone_number : "),
            "first_name" : input("first_name : "),
            "last_name": input("last_name : "),
            "username" : input("username : "),
            "photo" : "choose_emoji()",
            "bio" : input("bio : "),
        }


    def login(self):
        pass


    def account(self):
        pass
