from db.servise import DbService
from utils import random_code


class User(DbService):
    def __init__(self,
                 id: int = None,
                 phone_number: str = None,
                 first_name: str = None,
                 last_name: str = None,
                 username: str = None,
                 photo: str = None,
                 is_premium: bool = False,
                 bio: str = None):
        self.id = id
        self.phone_number = phone_number
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.photo = photo
        self.is_premium = is_premium
        self.bio = bio

    def sequence_id(self):
        pass


    def is_valid(self):
        pass


    def save(self):
        pass


    def send_code(self):
        pass


    def is_login(self):
        pass

