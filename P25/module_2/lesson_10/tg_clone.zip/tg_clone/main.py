from project.ui import UI

UI().main()