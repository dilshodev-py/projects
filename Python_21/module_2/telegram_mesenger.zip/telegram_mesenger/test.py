#
#
#
#
# class A:
#     def __init__(self,a  ,b):
#         self.a = a
#         self.b = b
#
#     @classmethod
#     def object_created(cls, *args, **kwargs):
#         return cls(*args , **kwargs)
#
#     @staticmethod
#     def other_function():
#         return 10
#
#     def test(self):
#         self.other_function()
#
#
# obj = A.object_created(b = 1 ,a =  2)
# print(obj.a)
#
#
#
#
#
#

