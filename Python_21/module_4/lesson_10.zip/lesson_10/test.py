# crontab - time control

# * - har
# backup.tar
# 00:00 - > 0 0 * * *
# %Y:%m:%d %H:%M:%S.tar

# pdp food
# bot :
#     8:30 menu yaratildi zakas bering
#     9:00 menu yaratildi zakas bering
#     9:30 menu yaratildi zakas bering
#     10:00 menu yaratildi zakas bering

# 0 8,9,10 * * *
# 0 8-10 * * *

# 30 8 * * *
# */30 9-10 * * *


with open("/home/dilshod/PycharmProjects/Python_21/module_4/lesson_10/hello.txt" , 'a') as f:
    f.write('\nhello world')