
"""collections
    dict
    str
    list
    set
    tuple
    UserList
    UserDict
    OrderDict
    namedTuple
    LinkedList
    Counter
    deque
    enum
    Lifoqueue
    Queue
    UserStr
    numpy
    Node


data structure:
    queue
    stack
    Tree
    Graph
    LinkedList



"""







