from module_3.lesson_4.ToDo.ui.main import UI

UI().main()