from module_3.lesson_4.ToDo.config.main import *
from module_3.lesson_4.ToDo.config.log_config import *