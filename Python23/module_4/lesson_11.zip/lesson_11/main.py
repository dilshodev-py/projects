import psycopg2


con = psycopg2.connect()
cur = con.cursor()


con.begin()
try:
    cur.execute('update1')
    cur.execute('update2')
    con.commit()
except:
    con.rollback()

