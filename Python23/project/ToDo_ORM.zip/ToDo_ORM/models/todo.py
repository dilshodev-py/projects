from project.ToDo_ORM.DB.main import DB


class ToDo(DB):
    pass