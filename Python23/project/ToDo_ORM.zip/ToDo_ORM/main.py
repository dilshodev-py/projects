from ui import UI

UI().main()